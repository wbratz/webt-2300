function myFunction1() {
    document.getElementById("demo2").innerHTML = "Paragraph changed!!";
  }